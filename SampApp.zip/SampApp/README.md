# Registration App

A full-stack single-page app with a React frontend and a Python (Flask) backend.
Captures **name, age, address** with validation on both client and server.

## Project structure

```
backend/    Flask API (validation + submission endpoint)
frontend/   React + Vite single-page form
```

## Backend setup

```bash
cd backend
python -m venv venv
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate

pip install -r requirements.txt
python app.py
```

The API runs at http://localhost:5000 with:
- `GET  /api/health` – health check
- `POST /api/submit` – accepts `{ name, age, address }`

## Frontend setup

```bash
cd frontend
npm install
npm run dev
```

The app runs at http://localhost:5173 and proxies `/api` requests to the backend.

## Validation rules

| Field   | Rules                                             |
|---------|---------------------------------------------------|
| Name    | Required, 2–50 chars, letters/spaces/`.`/`'`/`-`  |
| Age     | Required, whole number, 1–120                     |
| Address | Required, 5–200 chars                             |

Validation runs in the browser for instant feedback and again on the server as the source of truth.
