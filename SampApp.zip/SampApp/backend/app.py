"""Flask backend for the Registration app.

Exposes a single endpoint to accept and validate submissions
(name, age, address) sent from the React frontend.
"""
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# In-memory store for submissions (replace with a DB for production).
submissions = []


def validate_payload(data):
    """Validate the incoming payload. Returns a dict of field -> error."""
    errors = {}

    name = (data.get("name") or "").strip()
    age = data.get("age")
    address = (data.get("address") or "").strip()

    # Name: required, 2-50 chars, letters/spaces/.'- only
    if not name:
        errors["name"] = "Name is required."
    elif len(name) < 2:
        errors["name"] = "Name must be at least 2 characters."
    elif len(name) > 50:
        errors["name"] = "Name must be 50 characters or fewer."
    elif not all(c.isalpha() or c in " .'-" for c in name):
        errors["name"] = "Name may only contain letters, spaces, . ' and -."

    # Age: required, integer, 1-120
    if age is None or age == "":
        errors["age"] = "Age is required."
    else:
        try:
            age_int = int(age)
            if age_int < 1 or age_int > 120:
                errors["age"] = "Age must be between 1 and 120."
        except (ValueError, TypeError):
            errors["age"] = "Age must be a valid whole number."

    # Address: required, 5-200 chars
    if not address:
        errors["address"] = "Address is required."
    elif len(address) < 5:
        errors["address"] = "Address must be at least 5 characters."
    elif len(address) > 200:
        errors["address"] = "Address must be 200 characters or fewer."

    return errors


@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"}), 200


@app.route("/api/submit", methods=["POST"])
def submit():
    data = request.get_json(silent=True)
    if data is None:
        return jsonify({"message": "Invalid JSON body.", "errors": {}}), 400

    errors = validate_payload(data)
    if errors:
        return jsonify({"message": "Validation failed.", "errors": errors}), 422

    record = {
        "id": len(submissions) + 1,
        "name": data["name"].strip(),
        "age": int(data["age"]),
        "address": data["address"].strip(),
    }
    submissions.append(record)

    return jsonify({"message": "Submission received successfully.", "data": record}), 201


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
