import { useState } from 'react'

const initialForm = { name: '', age: '', address: '' }

function validate(values) {
  const errors = {}

  const name = values.name.trim()
  if (!name) {
    errors.name = 'Name is required.'
  } else if (name.length < 2) {
    errors.name = 'Name must be at least 2 characters.'
  } else if (name.length > 50) {
    errors.name = 'Name must be 50 characters or fewer.'
  } else if (!/^[A-Za-z .'-]+$/.test(name)) {
    errors.name = "Name may only contain letters, spaces, . ' and -."
  }

  const age = values.age
  if (age === '' || age === null) {
    errors.age = 'Age is required.'
  } else if (!/^\d+$/.test(String(age))) {
    errors.age = 'Age must be a valid whole number.'
  } else {
    const n = Number(age)
    if (n < 1 || n > 120) {
      errors.age = 'Age must be between 1 and 120.'
    }
  }

  const address = values.address.trim()
  if (!address) {
    errors.address = 'Address is required.'
  } else if (address.length < 5) {
    errors.address = 'Address must be at least 5 characters.'
  } else if (address.length > 200) {
    errors.address = 'Address must be 200 characters or fewer.'
  }

  return errors
}

export default function App() {
  const [values, setValues] = useState(initialForm)
  const [errors, setErrors] = useState({})
  const [touched, setTouched] = useState({})
  const [submitting, setSubmitting] = useState(false)
  const [status, setStatus] = useState(null) // { type: 'success'|'error', message }

  const handleChange = (e) => {
    const { name, value } = e.target
    const next = { ...values, [name]: value }
    setValues(next)
    if (touched[name]) {
      setErrors(validate(next))
    }
  }

  const handleBlur = (e) => {
    const { name } = e.target
    setTouched((t) => ({ ...t, [name]: true }))
    setErrors(validate(values))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setStatus(null)

    const validationErrors = validate(values)
    setErrors(validationErrors)
    setTouched({ name: true, age: true, address: true })

    if (Object.keys(validationErrors).length > 0) {
      return
    }

    setSubmitting(true)
    try {
      const res = await fetch('/api/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: values.name.trim(),
          age: Number(values.age),
          address: values.address.trim(),
        }),
      })

      const body = await res.json().catch(() => ({}))

      if (res.ok) {
        setStatus({ type: 'success', message: body.message || 'Submitted successfully.' })
        setValues(initialForm)
        setTouched({})
        setErrors({})
      } else if (body.errors && Object.keys(body.errors).length) {
        setErrors(body.errors)
        setStatus({ type: 'error', message: body.message || 'Please fix the errors below.' })
      } else {
        setStatus({ type: 'error', message: body.message || 'Something went wrong. Please try again.' })
      }
    } catch {
      setStatus({ type: 'error', message: 'Unable to reach the server. Please try again.' })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="page">
      <div className="card" role="main">
        <header className="card__header">
          <h1>Create your profile</h1>
          <p>Fill in the details below to get started.</p>
        </header>

        {status && (
          <div className={`alert alert--${status.type}`} role="status">
            {status.message}
          </div>
        )}

        <form onSubmit={handleSubmit} noValidate>
          <div className="field">
            <label htmlFor="name">Full name</label>
            <input
              id="name"
              name="name"
              type="text"
              placeholder="Jane Doe"
              value={values.name}
              onChange={handleChange}
              onBlur={handleBlur}
              className={errors.name && touched.name ? 'input input--error' : 'input'}
              aria-invalid={Boolean(errors.name && touched.name)}
              aria-describedby={errors.name && touched.name ? 'name-error' : undefined}
            />
            {errors.name && touched.name && (
              <span id="name-error" className="field__error">{errors.name}</span>
            )}
          </div>

          <div className="field">
            <label htmlFor="age">Age</label>
            <input
              id="age"
              name="age"
              type="number"
              min="1"
              max="120"
              placeholder="30"
              value={values.age}
              onChange={handleChange}
              onBlur={handleBlur}
              className={errors.age && touched.age ? 'input input--error' : 'input'}
              aria-invalid={Boolean(errors.age && touched.age)}
              aria-describedby={errors.age && touched.age ? 'age-error' : undefined}
            />
            {errors.age && touched.age && (
              <span id="age-error" className="field__error">{errors.age}</span>
            )}
          </div>

          <div className="field">
            <label htmlFor="address">Address</label>
            <textarea
              id="address"
              name="address"
              rows="3"
              placeholder="123 Main St, Springfield"
              value={values.address}
              onChange={handleChange}
              onBlur={handleBlur}
              className={errors.address && touched.address ? 'input input--error' : 'input'}
              aria-invalid={Boolean(errors.address && touched.address)}
              aria-describedby={errors.address && touched.address ? 'address-error' : undefined}
            />
            {errors.address && touched.address && (
              <span id="address-error" className="field__error">{errors.address}</span>
            )}
          </div>

          <button type="submit" className="btn" disabled={submitting}>
            {submitting ? 'Submitting…' : 'Submit'}
          </button>
        </form>
      </div>
    </div>
  )
}
